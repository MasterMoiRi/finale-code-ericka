<?php
include "connectdb.php";
session_start(); // REQUIRED to use $_SESSION

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['semail'])) {
        die("User not logged in.");
    }

    $email = $_SESSION['semail'];

    // Get user ID from users table using email
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($user_id);
    $stmt->fetch();
    $stmt->close();

    if (!$user_id) {
        die("User ID not found.");
    }

    // Insert each product into usersdata
    if (isset($_POST['product']) && is_array($_POST['product'])) {
        $products = $_POST['product'];
        $sizes = $_POST['size'];
        $qtys = $_POST['qty'];
        $totals = $_POST['total'];

        $stmt = $conn->prepare("INSERT INTO usersdata (id, product, size, qty, tprice) VALUES (?, ?, ?, ?, ?)");

        foreach ($products as $i => $product) {
            $size = $sizes[$i];
            $qty = (int)$qtys[$i];
            $total = (float)$totals[$i];

            $stmt->bind_param("issid", $user_id, $product, $size, $qty, $total);
            $stmt->execute();
        }

        $stmt->close();
        echo "Order submitted successfully!";
    } else {
        echo "No products received.";
    }
    header("Location: ../PHP/shoppingcart.php");
    exit;
}
?>
