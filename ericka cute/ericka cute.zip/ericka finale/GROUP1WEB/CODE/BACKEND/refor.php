<?php

include "connectdb.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (isset($_POST['Signup'])) {
        $email    = $_POST['Email'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $cpassword = $_POST['cpassword'];
        $address  = $_POST['address'];
        $pnum     = $_POST['pnum'];
        $age      = intval($_POST['age']);

        if ($password !== $cpassword) {
            echo "Passwords do not match.";
            exit();
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $discount = ($age >= 60) ? 20.00 : 0.00;

        // Check if email already exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $_SESSION["VEmail"] = true;
            header("Location: ../../index.php");
            exit();
        } else {
            $stmt = $conn->prepare("INSERT INTO users (name, email, password, address, pnum, age, discount_percentage)
                                    VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssid", $username, $email, $hashedPassword, $address, $pnum, $age, $discount);
            
            if ($stmt->execute()) {
                $_SESSION["Sreg"] = true;
                header("Location: ../../index.php");
                exit();
            } else {
                echo "Error: " . $conn->error;
            }
        }
    }

    // Forgot password
    if (isset($_POST['femail'])) {
        $email = $_POST['Email'];

        $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $_SESSION['email'] = $email;
            $_SESSION["efound"] = true;
            header("Location: forgot.php");
            exit;
        } else {
            $_SESSION['wemail'] = true;
            header("Location: forgot.php");
            exit;
        }
    }

    // Reset password
    if (isset($_POST["reset"])) {
        $email = $_POST['Email'];
        $password = $_POST["password"];
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashedPassword, $email);

        if ($stmt->execute()) {
            $_SESSION['sreset'] = true;
            header("Location: forgot.php");
            exit;
        }
    }
}
?>
