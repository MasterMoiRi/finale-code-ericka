<?php
include("../backend/connectdb.php");
session_start();

if (!isset($_SESSION['semail']) || empty($_SESSION['semail'])) {
    die('User email not found in session.');
}

require __DIR__ . '/../../PHPMailer/src/PHPMailer.php';
require __DIR__ . '/../../PHPMailer/src/SMTP.php';
require __DIR__ . '/../../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userEmail = $_SESSION['semail'];

    // Sanitize POST data
    $userName = htmlspecialchars($_POST['name'] ?? 'Customer');
    $address = htmlspecialchars($_POST['address'] ?? 'No address');
    $contact = htmlspecialchars($_POST['contact'] ?? 'No contact');
    $total_price = isset($_POST['total_price']) ? floatval($_POST['total_price']) : 0;
    $formattedTotal = '₱' . number_format($total_price, 2);


    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $userEmail);
    $stmt->execute();
    $stmt->bind_result($user_id);
    $stmt->fetch();
    $stmt->close();

    if (!$user_id) {
        die("User ID not found.");
    }

    // Insert each product into usersdata
    if (isset($_POST['product']) && is_array($_POST['product'])) {
        $products = $_POST['product'];
        $sizes = $_POST['size'];
        $qtys = $_POST['qty'];
        $totals = $_POST['total'];

        $stmt = $conn->prepare("INSERT INTO usersdata (id, product, size, quantity, tprice) VALUES (?, ?, ?, ?, ?)");

        foreach ($products as $i => $product) {
            $size = $sizes[$i];
            $qty = (int) $qtys[$i];
            $total = (float) $totals[$i];

            $stmt->bind_param("issid", $user_id, $product, $size, $qty, $total);
            $stmt->execute();
        }

        $stmt->close();


        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'mjazper03@gmail.com';
            $mail->Password = 'nkvw agrq hvth hcig'; // App password
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('mjazper03@gmail.com', 'HILEE Store');
            $mail->addAddress($userEmail, $userName);

            $mail->isHTML(true);
            $mail->Subject = 'Order Confirmation - HILEE';
            $mail->Body = "
            <h2>Thank you for your order!</h2>
            <p><strong>Name:</strong> $userName</p>
            <p><strong>Address:</strong> $address</p>
            <p><strong>Contact:</strong> $contact</p>
            <p><strong>Total Price:</strong> $formattedTotal</p>
            <br>
            <p>We appreciate your purchase!</p>
        ";

            $mail->send();
        } catch (Exception $e) {
            echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Order Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        h2 {
            color: #2c3e50;
        }

        p {
            font-size: 1.1em;
            color: #34495e;
            text-align: center;
            max-width: 600px;
        }

        a.button {
            margin-top: 25px;
            background-color: #27ae60;
            border: none;
            padding: 12px 25px;
            color: white;
            font-size: 1em;
            cursor: pointer;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        a.button:hover {
            background-color: #219150;
        }
    </style>
</head>

<body>
    <h2>Thank You for Purchasing from HILEE!</h2>
    <p>Your order has been placed successfully and a confirmation email has been sent to your inbox.</p>
    <p>We appreciate your business and hope to serve you again soon.</p>
    <a href="../php/shoppingcart.php" class="button">Back to Shopping Cart</a>
</body>

</html>