<?php
session_start();
$name = isset($_SESSION['sname']) ? $_SESSION['sname'] : '';
?>

<!DOCTYPE html>
<html>

<head>
    <title>Hilee</title>

    <!-- icon -->
    <link rel="shortcut icon" href="imgs-about/favicon-32x32.png" type="image/x-icon">
    <link rel="stylesheet" href="../style/about.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
</head>

<body>
<header>
    <div class="navbar">

      <div class="logo">
        <a href="../php/HILEETUMBLER.php"><img src="../../imgs/hilee.png"></a>
      </div>
      <ul>
        <li><a href="../php/HILEETUMBLER.php">Home</a></li>
        <li><a href="../PHP/about.php">About</a></li>
        <li><a href="../php/product.php">Product</a></li>
        <li>
          <a href="../php/shoppingcart.php" class="cart-icon">
            <i class="ri-shopping-cart-2-line"></i>
            <span class="cart-count">0</span>
          </a>
        </li>
        <li class="user-profile">
          <a href="../php/ACCOUNT.php" class="icon-link">
            <i class="fa fa-user"></i>
          </a>
          <span class="username"><?php echo $name; ?></span><br>
          <button><a href="../PHP/logout.php">Logout</a></button>
        </li>
      </ul>
    </div>
  </header>

    <div class="container">
        <h2>About</h2>

        <div class="text-content">
            <!-- 1st paragraph -->

            <p>
                Introducing Hilee tumblers, often seen as a budget-friendly alternative to brands like Hydro Flask,
                receive mixed reviews online, with some users finding them good for the price but others noting issues
                with insulation and coating durability.
            </p>
            <img src="../../IMGS/1.jpg" alt="pictue" />
        </div>

        <br />
        <!-- 2nd Page -->
        <div class="second-page">

            <div class="text-content-2">

                <!-- 2nd paragraph -->
                <p>
                    Hilee is a premium stainless steel double-walled insulated water bottlea that keeps hot liquids
                    heated
                    for up to 12 hours and iced drinks cold for 24 hours.
                </p>
                <img src="../../IMGS/2.jpg" alt="pictue" />
            </div>
        </div>
        <div class="third-page">
            <img src="../../IMGS/3.jpg" alt="pictue" />
        </div>
    </div>
</body>

</html>