<?php
include("../backend/connectdb.php");
session_start();

$adr = "";
$discountPercentage = 0;

if (isset($_SESSION['semail'])) {
    $stmt = $conn->prepare("SELECT ADDRESS, age FROM users WHERE email = ?");
    if ($stmt) {
        $stmt->bind_param("s", $_SESSION['semail']);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $adr = $row['ADDRESS'];
            $age = $row['age'];
            if ($age >= 60) {
                $discountPercentage = 20;
            }
        }
        $stmt->close();
    }
}

$name = isset($_SESSION['sname']) ? $_SESSION['sname'] : '';
?>
<!DOCTYPE html>
<html>

<head>
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="../style/product.css">
    <link rel="stylesheet" href="../style/check.css">
    <link rel="stylesheet" href="../style/HileeTumblerCart.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet" />
    <link rel="stylesheet" href="../style/mjcss.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" />
    <style>
        .order-summary-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 16px;
            display: none;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
            width: 5900%;
            max-width: 1150px;
            height: 450x;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 20px;
            z-index: 2000;
            overflow-y: auto;
        }

        .left-column,
        .right-column {
            flex: 1 1 45%;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 12px;
            box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.05);
        }

        .left-column h2 {
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
            border-bottom: 2px solid #e0e0e0;
            padding-bottom: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-weight: 600;
            display: block;
            margin-bottom: 8px;
            color: #444;
        }

        .form-input,
        .haha {
            width: 100%;
            padding: 10px 14px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
            background-color: #fefefe;
        }

        textarea.form-input {
            resize: vertical;
        }

        .totals {
            font-size: 16px;
            font-weight: bold;
            color: #2b2b2b;
            margin-left: 10px;
            display: inline-block;
        }

        .fortotals {
            font-weight: 500;
            color: #333;
        }

        .adrs {
            font-weight: 600;
            color: #444;
        }

        .form-button,
        .cancel-button {
            width: 48%;
            padding: 12px;
            border-radius: 6px;
            font-size: 16px;
            border: none;
            margin-top: 10px;
            transition: 0.3s;
        }

        .form-button {
            background-color: #28a745;
            color: white;
        }

        .form-button:hover {
            background-color: #218838;
        }

        .cancel-button {
            background-color: #dc3545;
            color: white;
        }

        .cancel-button:hover {
            background-color: #c82333;
        }

        @media screen and (max-width: 768px) {
            .order-summary-container {
                flex-direction: column;
                height: auto;
                max-height: 90vh;
            }

            .left-column,
            .right-column {
                flex: 1 1 100%;
                padding: 15px;
            }

            .form-button,
            .cancel-button {
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <div class="bgcontainer"></div>
    <header>
        <div class="navbar">

            <div class="logo">
                <a href="../php/HILEETUMBLER.php"><img src="../../imgs/hilee.png"></a>
            </div>
            <ul>
                <li><a href="../php/HILEETUMBLER.php">Home</a></li>
                <li><a href="../PHP/about.php">About</a></li>
                <li><a href="../php/product.php">Product</a></li>
                <li>
                    <a href="../php/shoppingcart.php" class="cart-icon">
                        <i class="ri-shopping-cart-2-line"></i>
                        <span class="cart-count">0</span>
                    </a>
                </li>
                <li class="user-profile">
                    <a href="../php/ACCOUNT.php" class="icon-link">
                        <i class="fa fa-user"></i>
                    </a>
                    <span class="username"><?php echo $name; ?></span><br>
                    <button><a href="../PHP/logout.php">Logout</a></button>
                </li>
            </ul>
        </div>
    </header>
    <br>
    <div class="cart">
        <div class="shopheader">
            <span>Product</span><span>Quantity</span><span>Price</span><span>Total</span><span>Remove</span>
        </div>

        <div class="popup-container">
            <div class="popup-message" id="popupMessage">Item successfully removed!</div>
        </div>

        <div class="hl-items"></div>

        <div class="hl-total">

            <h1>Shopping Cart Total</h1>
            <p>Subtotal <span class="subtotal">₱0</span></p>
            <p>Shipping Fee <span>Free</span></p>
            <p>TOTAL <span class="alltotal">₱0</span></p>
            <a href="../php/product.php"><button class="add-prod">Add Product</button></a>
            <button class="check-out" onclick="payment()">Check Out</button>
        </div>

        <form action="send_order_confirmation.php" method="POST" id="orderForm">
            <div class="order-summary-container" id="order">
                <div class="left-column">
                    <h2>Order Summary</h2>
                    <div class="form-group">
                        <label for="paymentMethod">Mode of Payment:</label>
                        <select id="paymentMethod" name="paymentMethod" class="form-input"
                            onclick="togglePaymentOptions()" required>
                            <option value="">Select Payment Method</option>
                            <option value="cod">Cash on Delivery</option>
                            <option value="online">Online Payment</option>
                        </select>
                    </div>
                    <div id="onlinePaymentOptions" class="hidden">
                        <div class="form-group">
                            <label for="onlinePaymentMethod">Select Online Payment Method:</label>
                            <select id="onlinePaymentMethod" name="onlinePaymentMethod" class="form-input">
                                <option value="">Select Payment Option</option>
                                <option value="gcash">GCash</option>
                                <option value="paymaya">PayMaya</option>
                            </select>
                        </div>
                        <div id="gcashNumberContainer" class="form-group hidden">
                            <label for="gcashNumber">Enter GCash Number:</label>
                            <input type="number" id="gcashNumber" name="gcashNumber" class="haha"
                                placeholder="09xxxxxxxxx">
                        </div>
                        <div id="paymayaNumberContainer" class="form-group hidden">
                            <label for="paymayaNumber">Enter PayMaya Number:</label>
                            <input type="number" id="paymayaNumber" name="paymayaNumber" class="haha"
                                placeholder="09xxxxxxxxx">
                        </div>
                    </div>
                    <div class="form-group"><label class="fortotals">Subtotal:</label>
                        <h5 class="totals" id="sub">₱0</h5>
                    </div>
                    <div class="form-group"><label class="fortotals">Shipping Fee:</label>
                        <h5 class="totals" id="deduc">₱Free</h5>
                    </div>
                    <div class="form-group"><label class="fortotals">Discount:</label>
                        <h5 class="totals" id="discount">₱0</h5>
                    </div>
                    <div class="form-group"><label class="fortotals">Total:</label>
                        <h5 class="totals" id="total">₱0</h5>
                    </div>
                    <input type="hidden" name="total" id="totalInput" value="0">
                    <input type="hidden" id="discountPercentage" value="<?php echo $discountPercentage; ?>">
                    <div class="form-group">
                        <label for="cashGiven" class="fortotals">Your Money:</label>
                        <input type="number" id="cashGiven" name="cashGiven" class="form-input"
                            placeholder="Enter amount (₱)" oninput="calculateChange()" required>
                    </div>
                    <div class="form-group">
                        <label class="fortotals">Change:</label>
                        <h5 class="totals" id="change">₱0.00</h5>
                    </div>
                </div>

                <div class="right-column">
                    <div class="form-group">
                        <label class="adrs" for="name">Name:</label>
                        <textarea name="name" id="name" class="form-input" placeholder="Enter Name" rows="3"
                            required></textarea>
                    </div>
                    <div class="form-group">
                        <label class="adrs" for="address">Address:</label>
                        <textarea name="address" id="address" class="form-input" placeholder="Enter Address" rows="3"
                            required><?php echo htmlspecialchars($adr); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="adrs" for="contact">Contact:</label>
                        <textarea name="contact" id="contact" class="form-input" placeholder="Enter Contact" rows="3"
                            required></textarea>
                    </div>
                    <input type="hidden" name="total" id="totalInput" value="0">
                    <br><br><br><br>
                    <form id="orderForm" action="../backend/usersdata.php" method="POST">
                        <div id="hiddenInputsContainer"></div>
                        <button type="button" class="form-button" onclick="orderNow()">Submit Order</button>
                    </form>
                    <button type="button" class="cancel-button" onclick="cancel()">Cancel</button>
                </div>
            </div>
        </form>

        <div id="removeMessage" class="remove-message hidden">Product successfully removed!</div>
        <div class="blurback" id="blurOverlay"></div>

        <div id="checkWrap">
            <h3 class="titleo" id="tite">HILEE</h3>
            <div class="checkmark-container">
                <div class="checkmark-circle">
                    <svg class="checkmark" viewBox="0 0 52 52">
                        <path class="checkmark-check" d="M14 27l10 10 20-20" />
                    </svg>
                </div>
            </div>
            <div class="messageo">Thank you for ordering!</div>
        </div>
    </div>

    <script src="../js/Product-Cart.js"></script>
    <script>
        function togglePaymentOptions() {
            const paymentMethod = document.getElementById('paymentMethod').value;
            document.getElementById('onlinePaymentOptions').classList.toggle('hidden', paymentMethod !== 'online');
        }

        document.addEventListener('DOMContentLoaded', function () {
            const methodSelector = document.getElementById('onlinePaymentMethod');
            if (methodSelector) {
                methodSelector.addEventListener('change', function () {
                    document.getElementById('gcashNumberContainer').classList.toggle('hidden', methodSelector.value !== 'gcash');
                    document.getElementById('paymayaNumberContainer').classList.toggle('hidden', methodSelector.value !== 'paymaya');
                });
            }
        });

        function payment() {

            const cart = JSON.parse(sessionStorage.getItem('cart') || '[]');

            if (cart.length === 0) {
                showPopupMessage("Your cart is empty! Add items before checking out.");
                return;
            }

            document.getElementById('order').style.display = "flex";
            document.getElementById('blurOverlay').style.display = "block";

            const subtotal = parseFloat(document.querySelector('.subtotal').textContent.replace(/[₱,]/g, '')) || 0;
            document.getElementById('sub').textContent = `₱${subtotal.toFixed(2)}`;
            recalculateTotal();


        }

        function cancel() {
            document.getElementById('order').style.display = "none";
            document.getElementById('blurOverlay').style.display = "none";
        }

        function recalculateTotal() {
            const subtotal = parseFloat(document.getElementById('sub').textContent.replace(/[₱,]/g, '')) || 0;
            const discountPercentage = parseFloat(document.getElementById('discountPercentage').value) || 0;

            const discountAmount = subtotal * (discountPercentage / 100);
            const discountedSubtotal = subtotal - discountAmount;
            const taxAmount = discountedSubtotal * 0.12;
            const total = discountedSubtotal + taxAmount;

            document.getElementById('discount').textContent = `₱${discountAmount.toFixed(2)}`;

            let taxDisplay = document.getElementById('tax');
            if (!taxDisplay) {
                const taxGroup = document.createElement('div');
                taxGroup.className = 'form-group';
                taxGroup.innerHTML = `<label class="fortotals">Tax (12%):</label><h5 class="totals" id="tax">₱${taxAmount.toFixed(2)}</h5>`;
                document.querySelector('#order .left-column').insertBefore(taxGroup, document.getElementById('total').parentNode);
            } else {
                taxDisplay.textContent = `₱${taxAmount.toFixed(2)}`;
            }

            document.getElementById('total').textContent = `₱${total.toFixed(2)}`;
            document.getElementById('totalInput').value = total.toFixed(2);

            calculateChange();
        }

        function calculateChange() {
            const cashGiven = parseFloat(document.getElementById('cashGiven')?.value) || 0;
            const total = parseFloat(document.getElementById('totalInput')?.value) || 0;
            const change = cashGiven - total;
            const changeElem = document.getElementById('change');
            if (changeElem) {
                changeElem.textContent = change >= 0 ? `₱${change.toFixed(2)}` : '₱0.00';
            }
        }


        function orderNow() {

            const form = document.getElementById("orderForm");
            const container = document.getElementById("hiddenInputsContainer");
            


            if (!form || !container) {
                console.error("Form or container element not found!");
                return;
            }

            // Clear old inputs to avoid duplicates
            container.innerHTML = "";

            // Build cart array from localStorage items
            let cart = [];
            const lastId = parseInt(localStorage.getItem("id")) || 0;

            for (let i = 1; i <= lastId; i++) {
                const product = localStorage.getItem(`product_${i}`);
                if (!product) continue;

                const size = localStorage.getItem(`size_${i}`) || "";
                const qty = parseInt(localStorage.getItem(`qty_${i}`)) || 0;
                const total = parseFloat(localStorage.getItem(`tprice_${i}`)) || 0;

                if (qty > 0) {
                    cart.push({
                        title: product,
                        size: size,
                        quantity: qty,
                        totalPrice: total
                    });
                }
            }

            if (cart.length === 0) {
                alert("Your cart is empty!");
                return;
            }

            // Add hidden inputs for each cart item
            cart.forEach(item => {
                container.innerHTML += `
            <input type="hidden" name="product[]" value="${item.title}">
            <input type="hidden" name="size[]" value="${item.size}">
            <input type="hidden" name="qty[]" value="${item.quantity}">
            <input type="hidden" name="total[]" value="${item.totalPrice.toFixed(2)}">
        `;
            });
           
            localStorage.clear();
            sessionStorage.clear();
            form.submit();
        }

    </script>
</body>

</html>