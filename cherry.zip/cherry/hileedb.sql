-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2025 at 08:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hileedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL,
  `ADDRESS` varchar(1000) DEFAULT NULL,
  `PNUM` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `discount_percentage` decimal(5,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `NAME`, `EMAIL`, `PASSWORD`, `ADDRESS`, `PNUM`, `age`, `discount_percentage`) VALUES
(11, 'joshuaisla', 'joshuaisla@gmail.com', '12345', NULL, NULL, NULL, 0.00),
(12, 'Mj', 'mjazper03@gmail.com', '$2y$10$SwqS3NvaUbG8EVqItQkUhuF6KNLULlFREMN.iwD9C69c4d008hfi.', 'cainta', 912124125, 60, 20.00),
(13, 'Mj', 'shyyiieee@gmail.com', '$2y$10$mI0Ku70CYI9ACBi9XZhfk.wKCaX33BV2GOle3VSDFyiPSbObSpjPG', 'cainta', 912385, 60, 20.00),
(14, 'isla', 'joshuaisla1@gmail.com', '$2y$10$07dHJd8JY5l6sxfreCUgJOViyNIIQ4nIX/F7zOCWPQddJBS3AuNzu', 'cainta', 91214, 20, 0.00),
(15, 'Jeric Jamisola', 'jeric@gmail.com', '$2y$10$2ctt1r.Zy6jPPC.tQ90LheVucKqca6OYCTQboEzK4qrgYh57RuwOS', '648 2nd St, Gruar, Sto Domingo, Cainta, Rizal', 912345678, 19, 0.00),
(17, 'Jeric Jamisola', 'jericj.jamisola@gmail.com', '$2y$10$6CwfLx.tHIcdHyamSSM4gO386d2kpJAoswNGg.ubRd47evF6Xu6qO', '648 2nd St, Gruar, Sto Domingo, Cainta, Rizal', 951234, 61, 20.00);

-- --------------------------------------------------------

--
-- Table structure for table `usersdata`
--

CREATE TABLE `usersdata` (
  `product_id` int(11) NOT NULL,
  `id` int(255) NOT NULL,
  `product` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `tprice` float NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usersdata`
--

INSERT INTO `usersdata` (`product_id`, `id`, `product`, `size`, `quantity`, `tprice`, `date`) VALUES
(20, 17, 'HILEE (Wax Apple) Premium Flask Hydration', '20oz', 1, 341.91, '2025-05-20'),
(21, 17, 'HILEE (Green Apple) Premium Flask Hydration', '20oz', 1, 341.91, '2025-05-20'),
(22, 17, 'HILEE (Pineapple) Premium Flask Hydration', '20oz', 2, 683.82, '2025-05-20'),
(23, 17, 'HILEE (Wax Apple) Premium Flask Hydration', '43oz', 1, 341.91, '2025-05-20'),
(24, 17, 'HILEE (Pineapple) Premium Flask Hydration', '33oz', 1, 341.91, '2025-05-20'),
(25, 17, 'HILEE (Green Apple) Premium Flask Hydration', '43oz', 1, 341.91, '2025-05-20'),
(26, 17, 'HILEE (Wax Apple) Premium Flask Hydration', '20oz', 1, 341.91, '2025-05-20'),
(27, 17, 'HILEE (Green Apple) Premium Flask Hydration', '20oz', 1, 341.91, '2025-05-20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`),
  ADD UNIQUE KEY `PNUM` (`PNUM`);

--
-- Indexes for table `usersdata`
--
ALTER TABLE `usersdata`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `usersdata`
--
ALTER TABLE `usersdata`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
